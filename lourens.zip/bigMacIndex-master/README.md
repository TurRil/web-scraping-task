# bigMacIndex
Web Scraping Tutorial in R that scrapes https://www.numbeo.com/cost-of-living/ for someone to look at goods in a similiar way in which Big Mac's do for the big Mac Index.
